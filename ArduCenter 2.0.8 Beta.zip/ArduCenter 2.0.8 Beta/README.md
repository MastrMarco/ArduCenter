[00] -> Dispositivi Aggiornati  10/05/23  

## Software
AreduCenter  Versione B2.0.7 t07 [Ottimizazione + Risolti vari BUG]  

## Dispositivi                               
ArduHubFanAudio 2.0 Versione Firmuware di Arduino B4.04V Versione Software PC AreduCenter2.0 2.0.7v [Ottimizazione + Risolti vari BUG]
     ArduHubFan 3.0 Versione Firmuware di Arduino B2.04V Versione Software PC AreduCenter2.0 2.0.7v [Ottimizazione + Risolti vari BUG]
     ArduHubFan 4.0 Versione Firmuware di Arduino B1.04V Versione Software PC AreduCenter2.0 2.0.7v [Ottimizazione + Risolti vari BUG]

## Info Aggiornamenti
Ver: 2.0.7 t07 Beta
- Risolti vari bug.
- Risolti alcuni bug grafici.
- Aggiunta la funzionalità StartFan [Imposta per un tot di secondi le ventole controllate in modo “Analogico” alla massima velocità quando si accende l’HUB o dopo lo standby del PC.
- Ora l’HUB riesce a riconoscere quando viene mandato il PC in standby].
- Ottimizzata l'animazione A-RGB “Discontinuo”.
- Ottimizzata la funzione “Protezione LED”, ora funziona come nel video 'Parte 3'.
- Ottimizzata la funzione “Protezione Dispositivo”, ora funziona come nel video 'Parte 3'.
- Risolto il bug di non chiusura del Software [avvolte quando si chiudeva il software essa rimaneva aperta in background].
- Attenzione bisogna aggiornare il Firmware dell’HUB con assieme il Software.
- Attenzione questa versione potrebbe aver portato alcuni bug sulla Connessione all’HUB in caso di problemi riprovate a riconnettervi.

## Scheda Tecnica ArduHubFan PC
![Scheda Tecnica ArduCenter ArduHubFan PC](https://user-images.githubusercontent.com/76437833/226737407-9d30d4f6-7207-4f55-8824-64b31325b2ff.png)
